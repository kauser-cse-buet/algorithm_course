Mathematical induction is technique to reason about correctness of programs.

Goal: prove P is correct for all input sizes.

To accomplish this goal, we have to carry out 2 steps:

(1) Prove P is correct for smallest inputs.
(2) Prove that if P is correct for input sizes 0, 1, ..., k, then P
is also correct for input size k+1.

